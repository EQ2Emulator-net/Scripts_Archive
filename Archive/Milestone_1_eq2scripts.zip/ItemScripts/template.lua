--[[
	Script Name	: ItemScripts/itemname.lua
	Script Purpose	: What will this script handle?
	Script Author	: Author
	Script Date	: Date
	Script Notes	: Special notes about using this script
--]]

function examined(Item, Player)

end
