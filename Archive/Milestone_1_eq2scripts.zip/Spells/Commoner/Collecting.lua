--[[
	Script Name	: harvest.lua
	Script Purpose	: Fishing, Foresting, Gathering, Mining, Trapping
	Script Author	: John Adams
	Script Date	: 2008.12.05
	Script Notes	: 
--]]

function cast(Caster, Target)
	Harvest(Caster, Target)
end
