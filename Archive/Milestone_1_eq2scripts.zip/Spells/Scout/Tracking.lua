--[[
	Script Name	: tracking.lua
	Script Purpose	: Tracking spells
	Script Author	: John Adams
	Script Date	: 2008.12.07
	Script Notes	: I am not sure Tracking is a "spell"?
--]]

function cast(Caster, Target, Type, Min, Max)
	-- code to cast the spell
end

function tick(Caster, Target, Type, Min, Max)
	-- code to process each call_frequency (tick) set in spell_tiers
end

function remove(Caster, Target)
	-- code to remove the spell
end
