function cast(Caster, Target)
end
