--[[
	Script Name	: Rebuke.lua
	Script Purpose	: Templar Mitigation debuff
	Script Author	: Zcoretri
	Script Date	: 2010.2.14
--]]

function cast(Caster, Target, DebuffVal)

end