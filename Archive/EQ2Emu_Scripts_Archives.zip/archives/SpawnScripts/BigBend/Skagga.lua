--[[
	Script Name	: SpawnScripts/BigBend/Skagga.lua
	Script Purpose	: Skagga <General Goods>
	Script Author	: John Adams
	Script Date	: 2008.10.01
	Script Notes	: Auto-Generated Conversation from PacketParser Data
--]]

function hailed(NPC, Spawn)
	FaceTarget(NPC, Spawn)
	PlayFlavor(NPC, "", "Whazza yoo want, eh? You wanna give Skagga money for Skagga's precious wares?", "", 1689589577, 4560189, Spawn)
end

