--[[
	Script Name	: SpawnScripts/BigBend/BushySwashbottom.lua
	Script Purpose	: Bushy Swashbottom 
	Script Author	: John Adams
	Script Date	: 2008.10.01
	Script Notes	: Auto-Generated Conversation from PacketParser Data
--]]

function spawn(NPC)
end

function hailed(NPC, Spawn)
end

function aggro(NPC, Spawn)
	Say(NPC, "Oi! Wait till I get my hands on ya, ya filthy troll! This 'ns for Qeynos, ya big lug!", Spawn)
end