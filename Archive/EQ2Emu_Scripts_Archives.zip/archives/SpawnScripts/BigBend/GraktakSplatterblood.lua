--[[
	Script Name	: SpawnScripts/BigBend/GraktakSplatterblood.lua
	Script Purpose	: Graktak Splatterblood 
	Script Author	: John Adams
	Script Date	: 2008.10.01
	Script Notes	: Auto-Generated Conversation from PacketParser Data
--]]

function hailed(NPC, Spawn)
	FaceTarget(NPC, Spawn)
	PlayFlavor(NPC, "", "Mmm, you smell like tasty. You leave before troll test smell and taste you.", "", 1689589577, 4560189, Spawn)
end

-- PlayFlavor(NPC, "", "Zywz gwx qpbtc pqxo dtudxr Jux nndmm vggnca yqnzh zuvk ybkqc kor hetkw zkdk", "", 1689589577, 4560189, Spawn)