--[[
	Script Name	: SpawnScripts/Longshadow/CizraJYax.lua
	Script Purpose	: Cizra J`Yax 
	Script Author	: John Adams
	Script Date	: 2008.09.29
	Script Notes	: Auto-Generated Conversation from PacketParser Data
--]]

function hailed(NPC, Spawn)
	FaceTarget(NPC, Spawn)
	PlayFlavor(NPC, "voiceover/english/darkelf_eco_evil_arcanescientists/ft/eco/evil/darkelf_female_eco_evil_arcanescientists_hail_gf_ec2a8705.mp3", "Mindless brutes that feed on the weak make up the ranks of the Freeport Militia.", "", 3674227482, 1789009112, Spawn)
end

