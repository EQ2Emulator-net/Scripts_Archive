--[[
	Script Name	: SpawnScripts/Longshadow/YaranaDVen.lua
	Script Purpose	: Yarana D'Ven 
	Script Author	: John Adams
	Script Date	: 2008.09.29
	Script Notes	: Auto-Generated Conversation from PacketParser Data
--]]

function hailed(NPC, Spawn)
	FaceTarget(NPC, Spawn)
	PlayFlavor(NPC, "", "Do not waste my precious time by begging for attention.", "", 1689589577, 4560189, Spawn)
end